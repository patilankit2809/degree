<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <link rel="stylesheet" href="http://use.fontawesome.com/releases/v5.7.0/css/all.css">

    <link rel="stylesheet" type="text/css" href="style.css">

    <link rel="icon" type="image/png" href="include/ttwicon.png">

    <title>Techtricksworld</title>
  </head>
  <body>
    <nav class="sticky-top navbar-expand-lg navbar-dark bg-dark nav1">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span><div class="menuicon">Menu</div> 
  </button>

  <div class="collapse navbar-collapse " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto" >
      <li class="nav-item">
        <a class="nav-link" href="index.php"><i class="fas fa-home" style=" font-size:0.9em;margin-left:2px;position:relative;"></i> Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="advertise.php"> Advertise</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="aboutus.php"> About us</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="contactus.php"> Contact us</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="privacypolicy.php"> Privacy policy</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="bloggingresources.php"> Blogging resources</a>
      </li>
    </ul>

      <i class="fab fa-twitter" id="twittericon"></i>
      <i class="fab fa-facebook-f" id="facebookicon"></i>
      <i class="fab fa-google-plus-g" id="googleplusicon"></i>
      <i class="fab fa-pinterest" id="pinteresticon"></i>
      <i class="fas fa-rss" id="rssicon"></i>
      <a class="nav-link signup" href="register.php"> Sign Up</a>
      
  </div>
</nav>
<div class="container-fluid main_body">
  <div class="ttwlogo">
  <a href="index.php"><img src="include/ttw.jpg" alt="logo" class="img-fluid" ></img></a>
  </div>
  <br>
  <br>
<div class="main_content">
  <nav class="navbar-expand-lg navbar-dark bg-dark nav2">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span><div class="browseicon">Browse</div>
    </button>

    <div class="collapse navbar-collapse innernav" id="navbarToggleExternalContent">
      <ul class="navbar-nav mr-auto" >
        <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==1){echo  'active';} ?>" href="navtemp.php?catid=1"> Apps</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==2){echo  'active';} ?>" href="navtemp.php?catid=2"> Blogging</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==3){echo  'active';} ?>" href="navtemp.php?catid=3"> Alternatives</a>
        </li>
         <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==4){echo  'active';} ?>" href="navtemp.php?catid=4"> SEO</a>
        </li>
         <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==5){echo  'active';} ?>" href="navtemp.php?catid=5"> Gadgets</a>
        </li>
         <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==6){echo  'active';} ?>" href="navtemp.php?catid=6"> How to</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==7){echo  'active';} ?>" href="navtemp.php?catid=7"> Software</a>
        </li>
         <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==8){echo  'active';} ?>" href="navtemp.php?catid=8"> Tips & Tricks</a>
        </li>
         <li class="nav-item">
          <a class="nav-link <?php if(isset($_GET["catid"]) && $_GET["catid"]==9){echo  'active';} ?>" href="navtemp.php?catid=9"> Tools </a>
        </li>

      </ul>
      <form class="form-inline my-2 my-lg-0" method="POST" action="search.php">
        <input class="form-control mr-sm-2" type="search" name="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
   </div> 
  </nav>