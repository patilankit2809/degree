 <table class="table table-responsive">
  <thead class="thead-dark">
    <tr>
      <th scope="col">id</th>
      <th scope="col">Title</th>
      <th scope="col">Author</th>
      <th scope="col">Timestamp</th>
      <th scope="col">Category</th>
      <!-- <th scope="col">Content</th> -->
      
    </tr>
  </thead>
  <?php while ($blog=mysqli_fetch_assoc($res2)){?>
  <tbody>
    
      <tr>
      <th scope="row"><?php $i=$blog["id"]; echo $i;?></th>
      <td><?php echo $blog["title"];?></td>
      <td><?php 
          mysqli_stmt_bind_param($stmt,"s",$blog["admin_id"]);
          mysqli_stmt_execute($stmt);
          $res3=mysqli_stmt_get_result($stmt);
        $admins=mysqli_fetch_assoc($res3);
        echo $admins["login"];
      ?></td>
      <td><?php $dat=$blog["timestamp"];$dat=date('d-m-y', strtotime(str_replace('-','/', $dat)));echo $dat;?></td>
      <td><?php 
        mysqli_stmt_bind_param($stmt2,"i",$blog["category_id"]);
          mysqli_stmt_execute($stmt2);
          $res4=mysqli_stmt_get_result($stmt2);
        $cat=mysqli_fetch_assoc($res4);
        echo $cat["category"];
      ?></td>
     <!--  <td><?php $cblog=substr($blog["content"],0,50); echo $cblog.'...';?></td> -->
    </tr>
  
   
  </tbody>
  <?php }?>
</table>