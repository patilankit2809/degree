<?php
require_once("./../include/config.php");
$name = mysqli_real_escape_string($conn,$_POST['name']);
$comment = mysqli_real_escape_string($conn,$_POST['comment']);
$q = "INSERT INTO comment (user,comment) VALUES('".$name."','".$comment."')";
mysqli_query($conn,$q);
?>